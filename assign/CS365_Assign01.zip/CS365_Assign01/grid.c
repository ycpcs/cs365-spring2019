#include <stdlib.h>
#include <string.h>
#include "grid.h"

Grid *grid_alloc(int rows, int cols)
{
	// TODO
	return (Grid*) 0;
}

void grid_destroy(Grid *grid)
{
	// TODO
}

void grid_flip(Grid *grid)
{
	// TODO
}

uint8_t grid_get_current(Grid *grid, int row, int col)
{
	// TODO
	return 0;
}

void grid_set_next(Grid *grid, int row, int col, uint8_t val)
{
	// TODO
}
