// Conway's Game of Life - parallel version

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include "grid.h"
#include "life.h"

// Set this to 1 to enable debug output, 0 to disable debug output
#define DEBUG 1

// The PDEBUG macro prints debug output if (and only if) DEBUG is true;
// use it exactly like printf
#if DEBUG == 1
#  define PDEBUG(args...) printf(args)
#else
#  define PDEBUG(args...)
#endif

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	if (argc != 5) {
		fprintf(stderr, "Usage: ./runpar <filename> <numgens> <N> <M>\n");
		exit(1);
	}

	const char *filename = argv[1];
	int numgens = atoi(argv[2]);
	int N = atoi(argv[3]);  // number of rows of processes
	int M = atoi(argv[4]);  // number of columns of processes

	PDEBUG("filename=%s, numgens=%i, N=%i, M=%i\n", filename, numgens, N, M);

	// TODO: computation

	MPI_Finalize();

	return 0;
}
