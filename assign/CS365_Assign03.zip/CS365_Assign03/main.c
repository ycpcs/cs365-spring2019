// N-Body simulation: GUI (shared by sequential and parallel versions)

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>
#include <unistd.h>
#include <pthread.h>
#include <ui.h>
#include "sim.h"

#define AREA_WIDTH 560
#define AREA_HEIGHT 560

#define BLACK 0x000000
#define WHITE 0xFFFFFF

#define FPS 20

static uiWindow *g_mainwin;
static uiArea *g_drawing_area;
static uiAreaHandler g_drawing_area_handler;

static Simulation *g_sim;

// Thread id for the animation timer thread
static pthread_t g_anim_thr;

// Set this to true to tell the animation timer thread to exit.
static volatile bool g_anim_quit = false;

// Flag keeping track of whether computation is running.
static volatile bool g_computing = false;

// Count of missed animation frames
static volatile int g_missed_frames;

// Total number of animation frames to display.
// Default (0) is to run forever.
static int g_max_frames;

// Handler for window close
static int onClosing(uiWindow *w, void *data) {
	// Tell animation timer thread to quit
	g_anim_quit = true;

	// Wait for the animation thread to exit
	pthread_join(g_anim_thr, NULL);

	// Destroy the Simulation object (and wait for worker threads to exit)
	sim_destroy(g_sim);

	uiControlDestroy(uiControl(g_mainwin));
	uiQuit();
	return 0;
}

// This is from the libui histogram example program.
static void setSolidBrush(uiDrawBrush *brush, uint32_t color, double alpha)
{
	uint8_t component;

	brush->Type = uiDrawBrushTypeSolid;
	component = (uint8_t) ((color >> 16) & 0xFF);
	brush->R = ((double) component) / 255;
	component = (uint8_t) ((color >> 8) & 0xFF);
	brush->G = ((double) component) / 255;
	component = (uint8_t) (color & 0xFF);
	brush->B = ((double) component) / 255;
	brush->A = alpha;
}

static void handlerMouseEvent(uiAreaHandler *a, uiArea *area, uiAreaMouseEvent *e) {
}

static void handlerMouseCrossed(uiAreaHandler *ah, uiArea *a, int left) {
}

static void handlerDragBroken(uiAreaHandler *ah, uiArea *a) {
}

static int handlerKeyEvent(uiAreaHandler *ah, uiArea *a, uiAreaKeyEvent *e) {
	return 0;
}

static void handlerDraw(uiAreaHandler *a, uiArea *area, uiAreaDrawParams *p) {
	//printf("Drawing! %dx%d\n", (int)p->AreaWidth, (int)p->AreaHeight);

	uiDrawPath *path;
	uiDrawBrush brush;

	// Draw black background
	setSolidBrush(&brush, BLACK, 1.0);
	path = uiDrawNewPath(uiDrawFillModeWinding);
	uiDrawPathAddRectangle(path, 0, 0, p->AreaWidth, p->AreaHeight);
	uiDrawPathEnd(path);
	uiDrawFill(p->Context, path, &brush);
	uiDrawFreePath(path);

	// Draw particles
	const int num_particles = sim_get_num_particles(g_sim);
	for (int i = 0; i < num_particles; i++) {
		const Particle *part = sim_get_particle(g_sim, i);
		int px = (int) (((part->x + (WIDTH/2)) / WIDTH) * AREA_WIDTH);
		int py = (int) (((part->y + (HEIGHT/2)) / HEIGHT) * AREA_HEIGHT);
		setSolidBrush(&brush, part->color, 1.0);

		path = uiDrawNewPath(uiDrawFillModeWinding);
		uiDrawPathAddRectangle(path, px, py, 1, 1);
		uiDrawPathEnd(path);
		uiDrawFill(p->Context, path, &brush);
		uiDrawFreePath(path);
	}
}

// Callback function responding to animation timer ticks.
static void onTick(void *data) {
	// If we're quitting, don't update the simulation or
	// attempt to redraw.
	if (g_anim_quit) {
		return;
	}

	//printf("Tick!\n");

	// Do computation for one timestep
	g_computing = true;
	sim_tick(g_sim);
	g_computing = false;

	// Force redraw
	uiAreaQueueRedrawAll(g_drawing_area);
}

static void onMaxFramesReached(void *arg) {
	onClosing(g_mainwin, NULL);
}

// This thread generates timer tick events, posting them as calls
// to onTick() on the main UI thread.  It can be stopped by setting
// g_anim_quit to true.
static void *animationTimerThread(void *arg) {
	int frame_count = 0;

	while (!g_anim_quit) {
		struct timespec ts;
		ts.tv_sec = 0;
		ts.tv_nsec = 1000000000 / FPS;
		nanosleep(&ts, NULL);

		// If the computation from the previous tick is still running,
		// count it as a missed animation frame (and don't schedule
		// the next tick yet.)
		if (g_computing) {
			__sync_fetch_and_add(&g_missed_frames, 1);
			continue;
		}

		uiQueueMain(onTick, arg);

		frame_count++;
		if (g_max_frames > 0 && frame_count >= g_max_frames) {
			g_anim_quit = true;
			uiQueueMain(onMaxFramesReached, NULL);
		}
	}
	return NULL;
}

// Callback to start animation timer thread.
// This needs to be done from the UI thread, because the UI thread
// will be waiting for the animation thread to exit (using pthread_join).
static void startAnimationTimer(void *data) {
	// Start the animation timer thread
	pthread_create(&g_anim_thr, NULL, animationTimerThread, NULL);
}

int main(int argc, char **argv) {
	uiInitOptions options;
	const char *err;

	// Initialize libui
	memset(&options, 0, sizeof (uiInitOptions));
	err = uiInit(&options);
	if (err != NULL) {
		fprintf(stderr, "error initializing libui: %s", err);
		uiFreeInitError(err);
		return 1;
	}

	// Create the Simulation object
	SimulationParams params = {
		.num_particles = DEFAULT_NUM_PARTICLES,
		.num_threads = DEFAULT_NUM_THREADS,
	};
	int opt;
	while ((opt = getopt(argc, argv, "p:t:f:")) != -1) {
		switch (opt) {
		case 'p':
			params.num_particles = atoi(optarg);
			break;
		case 't':
			params.num_threads = atoi(optarg);
			break;
		case 'f':
			g_max_frames = atoi(optarg);
			break;
		}
	}
	g_sim = sim_create(&params);

	// Start the animation thread
	uiQueueMain(startAnimationTimer, NULL);

	g_mainwin = uiNewWindow("N-Body simulation", AREA_WIDTH, AREA_HEIGHT, 1);
	uiWindowOnClosing(g_mainwin, onClosing, NULL);

	uiBox *hbox = uiNewHorizontalBox();
	uiBoxSetPadded(hbox, 1);
	uiWindowSetChild(g_mainwin, uiControl(hbox));

	g_drawing_area_handler.Draw = handlerDraw;
	g_drawing_area_handler.MouseEvent = handlerMouseEvent;
	g_drawing_area_handler.MouseCrossed = handlerMouseCrossed;
	g_drawing_area_handler.DragBroken = handlerDragBroken;
	g_drawing_area_handler.KeyEvent = handlerKeyEvent;

	g_drawing_area = uiNewArea(&g_drawing_area_handler);
	uiBoxAppend(hbox, uiControl(g_drawing_area), 1);

	uiControlShow(uiControl(g_mainwin));
	uiMain();

	// print count of missed animation frames
	printf("%i missed animation frame(s)\n", g_missed_frames);

	return 0;
}
