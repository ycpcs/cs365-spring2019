#include <math.h>
#include "particle.h"

static double randDouble(struct drand48_data *rng) {
	double val;
	drand48_r(rng, &val);
	return val;
}

static int randInt(struct drand48_data *rng) {
	long int val;
	mrand48_r(rng, &val);
	return (int)val;
}

//
// Initialize given particle with a random position and velocity.
//
void particle_init_rand(Particle *p, struct drand48_data *rng)
{
	double startWidth = WIDTH/4;
	double startHeight = HEIGHT/4;
	p->x = (randDouble(rng) * startWidth) - (startWidth / 2);
	p->y = (randDouble(rng) * startHeight) - (startHeight / 2);
	p->dx = (randDouble(rng) * 50.0) - 25.0;
	p->dy = (randDouble(rng) * 50.0) - 25.0;
	p->mass = 128000.0;
	p->color = randInt(rng) & 0xFFFFFF;
}

//
// Compute the distance between two particles.
//
double particle_dist(Particle *p1, Particle *p2)
{
	double xdist = p1->x - p2->x;
	double ydist = p1->y - p2->y;
	double dist = sqrt(xdist*xdist + ydist*ydist);
	return dist;
}

//
// Compute the attraction between two particles based on their
// distance from each other and their masses.
//
double particle_force(Particle *p1, Particle *p2)
{
	double dist = particle_dist(p1, p2);
	return (GCONST*p1->mass*p2->mass) / ((dist*dist) + SOFTENING);
}

//
// Compute the effect on p1's velocity based on its attraction to p2.
void particle_compute_attraction(Particle *p1, Particle *p2)
{
	double dist = particle_dist(p1, p2);
	double force = particle_force(p1, p2);
	//printf("dist=%lf, force=%lf\n", dist, force);
	double forcex = force * ((p2->x - p1->x) / dist);
	double forcey = force * ((p2->y - p1->y) / dist);
	p1->dx += (forcex / p1->mass);
	p1->dy += (forcey / p1->mass);
}

//
// Update a particle's position based on its velocity.
//
void particle_update_position(Particle *p)
{
	// The .01 scaling factor here is to make the simulation "smoother",
	// by decreasing the distance the particles move per time step.
	p->x += (p->dx * .01);
	p->y += (p->dy * .01);
}
