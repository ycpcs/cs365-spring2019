#ifndef PARTICLE_H
#define PARTICLE_H

#include <stdlib.h>  // for drand48_data

// Constants: note that the physical constants have been chosen
// somewhat arbitrarily

// Gravitational constant
#define GCONST 6.67384

// Softening factor (to limit the force when bodies are close)
#define SOFTENING 100000.0

// Width and height of simulation playing field
#define WIDTH 10000.0
#define HEIGHT 10000.0

// Struct type representing a single particle
typedef struct {
	double x, y;
	double dx, dy;
	double mass;
	int color;
} Particle;

// Prototypes for Particle functions
void particle_init_rand(Particle *p, struct drand48_data *buffer);
double particle_dist(Particle *p1, Particle *p2);
double particle_force(Particle *p1, Particle *p2);
void particle_compute_attraction(Particle *p1, Particle *p2);
void particle_update_position(Particle *p);

#endif // PARTICLE_H
