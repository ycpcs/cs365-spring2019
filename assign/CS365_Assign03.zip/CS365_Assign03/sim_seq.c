// N-body simulation: sequential implementation

#include <stdio.h>
#include <math.h>
#include "sim.h"

// Struct type representing the overall simulation
// (note that this is given the typedef name "Simulation"
// in sim.h)
struct Simulation_ {
	struct drand48_data rng;
	Particle *particles;
	int num_particles;
};

Simulation *sim_create(SimulationParams *params)
{
	Simulation *sim = malloc(sizeof(Simulation));

	// Seed the random number generator
	srand48_r(SEED, &sim->rng);

	sim->particles = malloc(params->num_particles * sizeof(Particle));
	sim->num_particles = params->num_particles;

	for (int i = 0; i < sim->num_particles; i++) {
		particle_init_rand(&sim->particles[i], &sim->rng);
	}

	return sim;
}

int sim_get_num_particles(Simulation *sim)
{
	return sim->num_particles;
}

Particle *sim_get_particle(Simulation *sim, int index)
{
	return &sim->particles[index];
}

void sim_destroy(Simulation *sim)
{
	free(sim->particles);
	free(sim);
}

void sim_tick(Simulation *sim)
{
	//printf("Tick\n");

	// Simulate the force on each particle due to the gravitational attraction
	// to all of other particles, and update each particle's velocity accordingly.
	for (int i = 0; i < sim->num_particles; i++) {
		for (int j = 0; j < sim->num_particles; j++) {
			if (i != j) {
				particle_compute_attraction(&sim->particles[i], &sim->particles[j]);
			}
		}
	}

	// Based on each particle's velocity, update its position.
	for (int i = 0; i < sim->num_particles; i++) {
		particle_update_position(&sim->particles[i]);
	}
}
