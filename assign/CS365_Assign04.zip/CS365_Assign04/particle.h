#ifndef PARTICLE_H
#define PARTICLE_H

#include <stdlib.h>  // for drand48_data

// Constants: note that the physical constants have been chosen
// somewhat arbitrarily

// Gravitational constant
#define GCONST 6.67384

// Softening factor (to limit the force when bodies are close)
#define SOFTENING 100000.0

// Width and height of simulation playing field
#define WIDTH 10000.0
#define HEIGHT 10000.0

// ParticleData represents all of the information about all of the
// particles in the overall simulation.  Separate arrays store
// x coordinates, y coordinates, horizontal velocities (dx),
// vertical velocities (dy), and mass.  Array elements with the
// same index represent information about the same individual
// particle.
typedef struct {
	float *x;
	float *y;
	float *dx;
	float *dy;
	float *mass;
	int *color;
} ParticleData;

void particle_data_alloc_buffers(ParticleData *pd, int num_particles);
void particle_data_free_buffers(ParticleData *pd);

void particle_init_rand(float *x, float *y, float *dx, float *dy, float *mass, int *color, int index, struct drand48_data *rng);
void particle_update_position(float *x, float *y, float *dx, float *dy, int index);

// These functions can be executed on either the CPU or GPU
#ifdef INCLUDE_PARTICLE_COMPUTATION_FUNCS
__host__ __device__ float particle_dist(float *x, float *y, int index1, int index2)
{
	float xdist = x[index1] - x[index2];
	float ydist = y[index1] - y[index2];
	float dist = (float)sqrt(xdist*xdist + ydist*ydist);
	return dist;
}

__host__ __device__ float particle_force(float *x, float *y, float *mass, int index1, int index2)
{
	float dist = particle_dist(x, y, index1, index2);
	return (GCONST*mass[index1]*mass[index2]) / ((dist*dist) + SOFTENING);
}

__host__ __device__ void particle_compute_attraction(float *x, float *y, float *dx, float *dy, float *mass, int index1, int index2)
{
	float dist = particle_dist(x, y, index1, index2);
	float force = particle_force(x, y, mass, index1, index2);
	float forcex = force * ((x[index2] - x[index1]) / dist);
	float forcey = force * ((y[index2] - y[index1]) / dist);
	dx[index1] += (forcex / mass[index1]);
	dy[index1] += (forcey / mass[index1]);
}
#endif

#endif // PARTICLE_H
