#ifndef SIM_H
#define SIM_H

#include "particle.h"

// See for random number generator
#define SEED 123L

// Number of particles to simulate (by default)
#define DEFAULT_NUM_PARTICLES 1024

// Number of threads (default for parallel version)
#define DEFAULT_NUM_THREADS 2

// Simulation parameters
typedef struct {
	int num_particles;
} SimulationParams;

// Declare Simulation as an opaque type
struct Simulation_;
typedef struct Simulation_ Simulation;

// Prototypes for Simulation functions
Simulation *sim_create(SimulationParams *params);
int sim_get_num_particles(Simulation *sim);
//Particle *sim_get_particle(Simulation *sim, int index);
float sim_get_particle_x(Simulation *sim, int index);
float sim_get_particle_y(Simulation *sim, int index);
int sim_get_particle_color(Simulation *sim, int index);
void sim_destroy(Simulation *sim);
void sim_tick(Simulation *sim);

#endif // SIM_H
