#include <stdio.h>
#include <stdlib.h>
#include "rule30.h"

State *rule30_load(FILE *fp)
{
	int num_cells;
	fscanf(fp, "%i", &num_cells);

	State *state = malloc(sizeof(State));
	state->num_cells = num_cells;

	state->cur = (uint8_t *) malloc(sizeof(uint8_t) * num_cells);
	for (int i = 0; i < num_cells; i++) {
		int value;
		fscanf(fp, "%i", &value);
		state->cur[i] = (uint8_t) value;
	}

	state->next = (uint8_t *) malloc(sizeof(uint8_t) * num_cells);

	return state;
}

void rule30_flip(State *state)
{
	uint8_t *tmp = state->cur;
	state->cur = state->next;
	state->next = tmp;
}

void rule30_compute_next(const uint8_t *current, uint8_t *next, int num_cells)
{
	// TODO: implement
}
