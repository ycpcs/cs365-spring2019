#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "rule30.h"

static void barf(const char *msg)
{
	printf("%s: %s\n", msg, strerror(errno));
	MPI_Finalize();
	exit(1);
}

static void print(State *state)
{
	for (int i = 0; i < state->num_cells; i++) {
		printf("%c", state->cur[i] != 0 ? 'x' : ' ');
	}
	printf("\n");
}

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	// Read initial state (every process can do this)
	FILE *fp = fopen(argv[1], "r");
	if (fp == NULL) {
		barf("Couldn't load initial state");
	}
	State *state = rule30_load(fp);
	fclose(fp);

	// Determine what work this processor should do
	int chunk_size = state->num_cells / size;
	int start = rank * chunk_size;
	if (rank == size - 1) {
		chunk_size += (state->num_cells % size);
	}

	//printf("process %i: range is %i..%i\n", rank, start, (start+chunk_size)-1);

	// Get ready for local computation: for example, copy part of the
	// global data (from state->cur) into a separate array
	// TODO

	// How many generations to simulate
	int num_gens = atoi(argv[2]);

	for (int i = 1; i <= num_gens; i++) {
		// send left?
		// TODO

		// receive from right?
		// TODO

		// send right?
		// TODO

		// receive from left?
		// TODO

		// local computation
		// TODO

		// flip current and next generation
		// TODO
	}

	// combine solutions
	if (rank == 0) {
		// prepare global data structure
		// TODO

		// copy local data
		// TODO

		// receive data from other processes
		// TODO
	} else {
		// Send local data to process 0
		// TODO
	}

	MPI_Finalize();

	return 0;
}
