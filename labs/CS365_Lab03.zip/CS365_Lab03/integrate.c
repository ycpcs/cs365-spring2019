#include <stdio.h>
#include <math.h>
#include <mpi.h>

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	double xmin, xmax;
	int nrects;

	if (rank == 0) {
		printf("xmin: ");
		fflush(stdout);
		scanf("%lf", &xmin);
	
		printf("xmax: ");
		fflush(stdout);
		scanf("%lf", &xmax);
	
		printf("nrects: ");
		fflush(stdout);
		scanf("%i", &nrects);
	}

	// Broadcast input values
	// TODO

	// Divide up work
	// TODO

	// Local computation
	// TODO

	// Reduce local partial results to produce one global result
	// TODO

	// Print the global result (process 0 only)
	// TODO

	MPI_Finalize();

	return 0;
}
