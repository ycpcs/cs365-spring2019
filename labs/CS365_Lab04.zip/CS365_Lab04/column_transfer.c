#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#define NCOLS 10
#define NROWS 10

static inline int compute_index(int row, int col)
{
	return row*NCOLS + col;
}

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	// Pretend this is a 2D array with NROWS rows and NCOLS columns
	int *grid = malloc(NROWS*NCOLS*sizeof(int));

	// Fill it with zeroes
	for (int i = 0; i < NROWS*NCOLS; i++) {
		grid[i] = 0;
	}

	// Process 0 only: fill the rightmost "column" with predetermined values
	if (rank == 0) {
		for (int j = 0; j < NROWS; j++) {
			int index = compute_index(j, NCOLS-1);
			grid[index] = (j+1)*9; // multiples of 9
		}
	}

	// TODO: create a column datatype

	if (rank == 0) {
		// Send rightmost column of values to process 1

		// TODO: use column datatype to send all values at once
		for (int j = 0; j < NROWS; j++) {
			int row = j;
			int col = (NCOLS-1); // rightmost column
			int index = row*NCOLS + col;
			MPI_Send(&grid[index], 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
		}
	} else if (rank == 1) {
		// Receive rightmost column of values from process 0,
		// putting it in this process's leftmost column

		// TODO: use column datatype to receive all values at once
		for (int j = 0; j < NROWS; j++) {
			int index = compute_index(j, 0);
			MPI_Status unused;
			MPI_Recv(&grid[index], 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &unused);
		}
	}

	// Have process 1 print out the received values
	if (rank == 1) {
		printf("Process %i: ", rank);
		for (int j = 0; j < NROWS; j++) {
			int index = compute_index(j, 0);
			printf("%i ", grid[index]);
		}
		printf("\n");
	}

	MPI_Finalize();

	return 0;
}
