#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>

#include "utime.h" // for the utime() function

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	// TODO: add your code here

	MPI_Finalize();

	return 0;
}
