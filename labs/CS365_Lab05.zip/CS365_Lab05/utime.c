#ifdef UTIME_TEST
#  include <stdio.h>
#  include <unistd.h>
#endif
#include <stdlib.h>
#include <sys/time.h>

#include "utime.h"

unsigned long utime(void)
{
	struct timeval tv;
	unsigned long result = 0;

	gettimeofday(&tv, NULL);
	result += (tv.tv_sec * 1000000);
	result += tv.tv_usec;

	return result;
}

#ifdef UTIME_TEST
int main(void)
{
	unsigned long start, end;

	start = utime();
	printf("Sleeping...\n");
	sleep(1);
	end = utime();

	printf("%lu ms elapsed\n", end - start);

	return 0;
}
#endif
