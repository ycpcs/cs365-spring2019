#ifndef UTIME_H
#define UTIME_H

unsigned long utime(void);

#endif // UTIME_H
