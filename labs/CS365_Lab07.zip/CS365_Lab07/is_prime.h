#ifndef IS_PRIME_H
#define IS_PRIME_H

int is_prime(int n);

#endif // IS_PRIME_H
