#! /bin/bash

java -classpath bin edu.ycp.cs365.boundedqueue.SimulationFrame
