package edu.ycp.cs365.fjsort;

import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ForkJoinPool;

public class Benchmark {
	private static final boolean INTERACTIVE = Boolean.getBoolean("interactive");

	public static void main(String[] args) throws InterruptedException {
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		
		if (INTERACTIVE) {
			System.out.print("Sequential (0) or parallel (1)? ");
		}
		int mode = keyboard.nextInt();
		//System.out.println("Mode is " + mode);
		System.out.println(((mode == 0) ? "Sequential" : "Parallel") + " execution");

		for (int size = 2000000; size <= 20000000; size += 2000000) {
			benchmark(mode, size);
		}
	}

	private static void benchmark(int mode, int size) {
		int[] arr = Benchmark.createRandomArray(size, new Random(123L));
		
		long begin = System.currentTimeMillis();
		if (mode == 0) {
			// Sequential quicksort
			Sort.quickSort(arr, 0, arr.length);
		} else {
			int numCores = Runtime.getRuntime().availableProcessors();
			
			// Create the ForkJoinPool with the worker threads (one thread per available core)
			ForkJoinPool pool = new ForkJoinPool(numCores);
			
			// TODO: set this to something reasonable
			// Hint: think about the number of array elements and the number of cores
			int granularity = 10000;
			
			// Create the root task to sort the entire array
			QuickSortTask root = new QuickSortTask(arr, 0, arr.length, granularity);
			
			// Invoke the root task and wait for it to finish
			pool.invoke(root);
		}
		long end = System.currentTimeMillis();

		// Print problem size (number of elements) and elapsed time
		System.out.println(size + "," + (end - begin));
		
		if (!isSorted(arr)) {
			throw new IllegalStateException("Array is not sorted!");
		}
	}

	private static int[] createRandomArray(int size, Random r) {
		int[] a = new int[size];
		
		// Create a completely sorted array
		for (int i = 0; i < size; i++) {
			a[i] = i;
		}
		
		// Shuffle the array elements
		// See: http://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle
		for (int i = size-1; i > 0; i--) {
			int j = r.nextInt(i+1);
			int tmp = a[i];
			a[i] = a[j];
			a[j] = tmp;
		}
		
		return a;
	}

	private static boolean isSorted(int[] a) {
		for (int i = 1; i < a.length; i++) {
			if (a[i] < a[i-1]) {
				return false;
			}
		}
		return true;
	}

}
