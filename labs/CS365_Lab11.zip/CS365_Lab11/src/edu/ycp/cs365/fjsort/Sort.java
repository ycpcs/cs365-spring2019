package edu.ycp.cs365.fjsort;

import java.util.Arrays;

public class Sort {
	/**
	 * Partition given region of array.
	 * 
	 * @param arr    the array
	 * @param start  the start of the region (inclusive)
	 * @param end    the end of the region (exclusive)
	 * @return the index where the pivot element was placed
	 */
	public static int partition(int[] arr, int start, int end) {
		int tmp;

		int pivotIndex = start + (end-start)/2;
		int pivot = arr[pivotIndex];
		
		// Swap pivot with last element in range
		tmp = arr[pivotIndex];
		arr[pivotIndex] = arr[end-1];
		arr[end-1] = tmp;
		
		// Starting from both ends of range, build up partitions
		int i = start, j = end-2;
		while (i <= j) {
			if (arr[i] < pivot) {
				i++; // increase size of left partition
			} else if (arr[j] >= pivot) {
				j--; // increase size of right partition
			} else {
				// swap elements and increase sizes of both partitions
				tmp = arr[i];
				arr[i] = arr[j];
				arr[j] = tmp;
				i++;
				j++;
			}
		}
		
		// i now refers to the first element of the right partition,
		// so put the pivot element there to get it in the right place
		tmp = arr[i];
		arr[i] = arr[end-1];
		arr[end-1] = tmp;
		
		// pivot is now at index i
		return i;
	}
	
	/**
	 * Sequential quicksort.
	 * 
	 * @param arr    the array
	 * @param start  the start index (inclusive)
	 * @param end    the end index (exclusive)
	 */
	public static void quickSort(int[] arr, int start, int end) {
		if (end - start < 5) {
			// Sequential sort
			Arrays.sort(arr, start, end);
		} else {
			// Sequential partition
			int mid = Sort.partition(arr, start, end);
			
			// Recursively sort partitions
			quickSort(arr, start, mid);
			quickSort(arr, mid+1, end);
		}
	}
}
