#! /usr/bin/env bash

java -classpath bin:$CLASSPATH edu.ycp.cs365.rng.Benchmark
