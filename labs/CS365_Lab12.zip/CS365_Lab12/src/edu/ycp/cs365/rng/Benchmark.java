package edu.ycp.cs365.rng;

public class Benchmark {
	private static final int NUM_TRIALS = 10000000;

	static class Worker implements Runnable {
		RandomNumberGenerator rng;
		int numTrials;
		long sum;

		public Worker(RandomNumberGenerator rng, int numTrials) {
			this.rng = rng;
			this.numTrials = numTrials;
			this.sum = 0L;
		}

		public void run() {
			for (int i = 0; i < numTrials; i++) {
				sum += rng.nextInt();
			}
		}

		public long getSum() { return sum; }
	}

	public static void main(String[] args) throws InterruptedException {
		RandomNumberGenerator rng;

		// TODO: adjust this
		int numThreads = 2;

		// TODO: comment out one of these
		rng = new LockBasedRNG();
		//rng = new LockFreeRNG();

		System.out.printf("Testing %s for %d trials\n", rng.getClass().getSimpleName(), NUM_TRIALS);

		// Create worker tasks
		Worker[] workers = new Worker[numThreads];
		for (int i = 0; i < numThreads; i++) {
			int numTrials = NUM_TRIALS / numThreads;
			if (i == numThreads - 1) {
				numTrials += (NUM_TRIALS % numThreads);
			}
			workers[i] = new Worker(rng, numTrials);
		}

		// Start worker tasks
		Thread[] threads = new Thread[numThreads];
		for (int i = 0; i < numThreads; i++) {
			threads[i] = new Thread(workers[i]);
			threads[i].start();
		}

		// Wait for threads to finish
		for (Thread t : threads) { t.join(); }

		// Compute result
		long sum = 0L;
		for (Worker w : workers) { sum += w.getSum(); }

		System.out.printf("Overall sum is %d\n", sum);
	}
}
