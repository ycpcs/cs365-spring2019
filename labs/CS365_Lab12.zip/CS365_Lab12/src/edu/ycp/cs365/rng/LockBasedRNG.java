package edu.ycp.cs365.rng;

public class LockBasedRNG implements RandomNumberGenerator {
	private Object lock;
	private long seed;
	
	public LockBasedRNG() {
		lock = new Object();
		seed = 123L;
	}
	
	public int nextInt() {
		synchronized (lock) {
			seed = (seed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1);
			return (int)(seed >>> (48 - 32));
		}
	}
}
