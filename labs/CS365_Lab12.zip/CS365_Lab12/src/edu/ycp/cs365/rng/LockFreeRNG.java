package edu.ycp.cs365.rng;

// TODO: modify this code to use an AtomicLong and eliminate
// the use of the lock
public class LockFreeRNG implements RandomNumberGenerator {
	private Object lock;
	private long seed;
	
	public LockFreeRNG() {
		lock = new Object();
		seed = 123L;
	}
	
	public int nextInt() {
		synchronized (lock) {
			seed = (seed * 0x5DEECE66DL + 0xBL) & ((1L << 48) - 1);
			return (int)(seed >>> (48 - 32));
		}
	}
}
