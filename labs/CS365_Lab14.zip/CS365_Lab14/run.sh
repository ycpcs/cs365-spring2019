#! /bin/bash

cls="$1"
if [ -z "$cls" ]; then
	echo "Usage: run.sh <class name> <args...>"
	exit 1
fi

shift

java -classpath bin edu.ycp.cs365.sockets.${cls} "$@"
