package edu.ycp.cs365.sockets;

import java.io.Closeable;
import java.io.IOException;

public class IOUtil {

	public static void closeQuietly(Closeable obj) {
		if (obj != null) {
			try {
				obj.close();
			} catch (IOException e) {
				System.err.println("Error closing " + obj.getClass().getSimpleName() +
						": " + e.getMessage());
			}
		}
	}

}
