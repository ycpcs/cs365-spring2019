package edu.ycp.cs365.sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;

// TODO: modify the server so that it reads two integer values
// from the client, computes the sum, and sends the result
// back to the client.
public class Server {
	private static final Charset UTF8 = Charset.forName("UTF-8");
	
	public static void main(String[] args) throws IOException {
		if (args.length < 1) {
			System.out.println("Usage: " + Server.class.getName() + " <port>");
			System.exit(1);
		}
		int port = Integer.parseInt(args[0]);
		
		System.out.println("Listening for connections on port " + port);
		
		ServerSocket ssock = new ServerSocket(port);
		
		try {
			boolean keepGoing = true;
			while (keepGoing) {
				Socket client = ssock.accept();
				keepGoing = chat(client);
			}
		} finally {
			IOUtil.closeQuietly(ssock);
		}
	}

	private static boolean chat(Socket client) throws IOException {
		boolean keepGoing = true;
		
		BufferedReader reader = null;
		PrintWriter writer = null;
		
		try {
			reader = new BufferedReader(new InputStreamReader(client.getInputStream(), UTF8));
			writer = new PrintWriter(new OutputStreamWriter(client.getOutputStream(), UTF8));
			
			String message = reader.readLine();
			if (message != null) {
				System.out.println("Received: " + message);
				
				writer.println(message);
				writer.flush();
			}
		} finally {
			IOUtil.closeQuietly(reader);
			IOUtil.closeQuietly(writer);
		}
		
		return keepGoing;
	}
}
