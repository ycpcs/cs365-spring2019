#! /bin/sh

java -classpath bin edu.ycp.cs365.queues.Benchmark
