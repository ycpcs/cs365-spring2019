package edu.ycp.cs365.queues;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Scanner;

public class Benchmark {
	static class Worker implements Runnable {
		private IQueue<Integer> queue;
		private int numIters, thinkTime;
		private volatile long count;
		
		public Worker(IQueue<Integer> queue, int numIters, int thinkTime) {
			this.queue = queue;
			this.numIters = numIters;
			this.thinkTime = thinkTime;
			this.count = 0L;
		}
		
		@Override
		public void run() {
			for (int i = 0; i < numIters; i++) {
				queue.enqueue(i);
				for (int j = 0; j < thinkTime*10; j++) {
					count++;
				}
				queue.dequeue();
			}
		}
		
		public long getCount() {
			return count;
		}
	}
	
	public static void main(String[] args) throws InterruptedException, IOException {
		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
		
		int numThreads, numIters, thinkTime;
		System.out.print("Number of threads: ");
		numThreads = keyboard.nextInt();
		System.out.print("Number of iterations: ");
		numIters = keyboard.nextInt();
		System.out.print("Think time: ");
		thinkTime = keyboard.nextInt();
		
		System.out.print("Queue implementation (0=blocking, 1=nonblocking): ");
		int queueImpl = keyboard.nextInt();
		IQueue<Integer> queue = (queueImpl == 0)
				? new TwoLockQueue<Integer>() : new NonBlockingQueue<Integer>(); 
		
		// Create worker tasks;
		Worker[] tasks = new Worker[numThreads];
		for (int i = 0; i < numThreads; i++) {
			tasks[i] = new Worker(queue, numIters/numThreads, thinkTime);
		}
		
		System.out.print("Running...");
		System.out.flush();
		
		long start = System.currentTimeMillis();
		
		// Create and start threads
		Thread[] threads = new Thread[numThreads];
		for (int i = 0; i < numThreads; i++) {
			threads[i] = new Thread(tasks[i]);
			threads[i].start();
		}
		
		// Wait for threads to finish
		for (int i = 0; i < numThreads; i++) {
			threads[i].join();
		}
		
		long end = System.currentTimeMillis();
		
		System.out.println("Done\nElapsed time: " + (end-start) + " ms");
		
		// Just to ensure the compiler doesn't optimize away the
		// counts used to implement the think time
		try (PrintWriter w = new PrintWriter(new FileWriter("/dev/null"))) {
			for (Worker task : tasks) {
				w.println(task.getCount());
			}
		}
	}
}
