package edu.ycp.cs365.queues;

public interface IQueue<E> {
	public void enqueue(E value);
	public E dequeue();
}
