package edu.ycp.cs365.queues;

import java.util.concurrent.atomic.AtomicReference;

public class NonBlockingQueue<E> implements IQueue<E> {
	static class Node<E> {
		E value;
		AtomicReference<Node<E>> next = new AtomicReference<Node<E>>();
	}
	
	private AtomicReference<Node<E>> head, tail;

	public NonBlockingQueue() {
		Node<E> node = new Node<E>();
		head = new AtomicReference<Node<E>>();
		tail = new AtomicReference<Node<E>>();
		head.set(node);
		tail.set(node);
	}
	
	@Override
	public void enqueue(E value) {
		// Create node to enqueue
		Node<E> node = new Node<E>();
		node.value = value;
		node.next.set(null);
		Node<E> tail;
		while (true) {
			// Read tail and tail.next
			tail = this.tail.get();
			Node<E> next = tail.next.get();
			// If tail hasn't changed, and tail appears to point to the last node...
			if (tail == this.tail.get()) {
				if (next == null) {
					// Attempt to enqueue the node onto the tail node
					if (tail.next.compareAndSet(next, node)) {
						// Success!
						break;
					}
				} else {
					// Tail isn't pointing to the last node, attempt to update it
					this.tail.compareAndSet(tail, next);
				}
			}
		}
		// Attempt to set tail to the enqueued node
		this.tail.compareAndSet(tail, node);
	}

	@Override
	public E dequeue() {
		while (true) {
			Node<E> head = this.head.get();
			Node<E> tail = this.tail.get();
			Node<E> next = head.next.get();
			if (head == this.head.get()) {
				if (head == tail) {
					if (next == null) {
						// Queue was observed to be empty
						return null;
					}
					// A node was appended, but tail hasn't been updated yet,
					// so try to update it
					this.tail.compareAndSet(tail, next);
				} else {
					E value = next.value;
					if (this.head.compareAndSet(head, next)) {
						// Successfully dequeued a node
						
						// At this point it is safe to remove the reference
						// to the value (to prevent an unnecessary reference to
						// it from being kept by the queue)
						next.value = null;
						
						return value;
					}
				}
			}
		}
	}
}
