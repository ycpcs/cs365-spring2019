package edu.ycp.cs365.queues;

public class TwoLockQueue<E> implements IQueue<E> {
	static class Node<E> {
		E value;
		Node<E> next;
	}

	private Node<E> head, tail;
	private Object h_lock, t_lock;
	
	public TwoLockQueue() {
		head = tail = new Node<E>();
		h_lock = new Object();
		t_lock = new Object();
	}

	@Override
	public void enqueue(E value) {
		Node<E> node = new Node<E>();
		node.value = value;
		node.next = null;
		synchronized (t_lock) {
			tail.next = node;
			tail = node;
		}
	}

	@Override
	public E dequeue() {
		synchronized (h_lock) {
			Node<E> node = head;
			Node<E> new_head = node.next;
			if (new_head == null) {
				// Queue is empty, dequeue fails
				return null;
			}
			head = new_head;
			E result = new_head.value;
			new_head.value = null; // don't retain a reference to the value being dequeued
			return result;
		}
	}

}
