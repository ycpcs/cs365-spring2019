Compile by running the command

    gradle build

Run the benchmark using the command

    ./run.sh [options]

Options include

    -DforceSequential=true               force sequential computation
    -DnumProcs=N                         use N threads in thread pool
