#! /bin/bash

# Collect arguments
args=''
while [ $# -gt 0 ] && [ $(expr "$1" : '-') = '1' ]; do
	args="$args $1"
	shift
done

#echo "args=$args"

java -classpath bin:$CLASSPATH $args edu.ycp.cs365.forkjoin.MergeSort
