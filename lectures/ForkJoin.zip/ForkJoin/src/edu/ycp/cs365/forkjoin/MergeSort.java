package edu.ycp.cs365.forkjoin;

import java.util.Arrays;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class MergeSort {
	private static final boolean PARALLEL = !Boolean.getBoolean("forceSequential");
	private static final boolean VERIFY_CORRECT = Boolean.getBoolean("verifyCorrect");
	private static final boolean DEBUG = Boolean.getBoolean("debug");

	private static class MergeSortTask extends RecursiveAction {
		private static final long serialVersionUID = 1L;
		private int[] arr;
		private int start, end;
		private int threshold;

		public MergeSortTask(int[] arr, int start, int end, int threshold) {
			this.arr = arr;
			this.start = start;
			this.end = end;
			this.threshold = threshold;
		}

		@Override
		protected void compute() {
			try {
				if (DEBUG) System.out.println(start + ".." + end + " start");
				if (end - start <= threshold || !PARALLEL) {
					// sequential sort
					Arrays.sort(arr, start, end);
					return;
				}

				// Sort halves in parallel
				int mid = start + (end-start) / 2;
				invokeAll(new MergeSortTask(arr, start, mid, threshold), new MergeSortTask(arr, mid, end, threshold));

				// sequential merge
				sequentialMerge(mid);
			} finally {
				if (DEBUG) System.out.println(start + ".." + end + " end");
			}
		}

		private void sequentialMerge(int mid) {
			// merge sub-arrays into temporary array
			int[] temp = new int[end - start];
			int i = 0, j = start, k = mid;
			while (true) {
				if (j >= mid) {
					System.arraycopy(arr, k, temp, i, end - k);
					break;
				}
				if (k >= end) {
					System.arraycopy(arr, j, temp, i, mid - j);
					break;
				}
				int left = arr[j];
				int right = arr[k];
				if (left < right) {
					temp[i++] = left;
					j++;
				} else {
					temp[i++] = right;
					k++;
				}
			}

			// copy sorted temp array back to main array
			System.arraycopy(temp, 0, arr, start, temp.length);
		}
	}

	private static final int CHUNK = 2000000;
	private static final int MAX = 20000000;
	private static final int NUM_PROCS = Integer.getInteger("numProcs", Runtime.getRuntime().availableProcessors());

	public static void main(String[] args) {
		//int arrSize = 20000000;

		for (int arrSize = CHUNK; arrSize <= MAX; arrSize += CHUNK) {
			int[] data = Util.makeRandomArray(arrSize);

			System.gc();
			long elapsed = benchmark(data);

			System.out.println(arrSize + "," + elapsed);

			if (VERIFY_CORRECT && !Util.isSorted(data)) {
				// verify that the data is now sorted
				System.out.println("ERROR: data is not sorted!");
			}
		}
	}

	private static long benchmark(int[] data) {
		long begin = System.currentTimeMillis();

		MergeSortTask rootTask = new MergeSortTask(data, 0, data.length, data.length / Runtime.getRuntime().availableProcessors());
		ForkJoinPool pool = new ForkJoinPool(NUM_PROCS);
		pool.invoke(rootTask);
		long end = System.currentTimeMillis();
		long elapsed = end - begin;
		return elapsed;
	}
}
