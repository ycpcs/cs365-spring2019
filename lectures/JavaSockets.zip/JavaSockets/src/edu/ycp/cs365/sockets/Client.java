package edu.ycp.cs365.sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.charset.Charset;

public class Client {
	private static final Charset UTF8 = Charset.forName("UTF-8");
	
	public static void main(String[] args) throws UnknownHostException, IOException {
		
		if (args.length < 3) {
			System.out.println("Usage: " + Client.class.getName() + " <hostname> <port> <message>");
			System.exit(1);
		}
		
		String host = args[0];
		int port = Integer.parseInt(args[1]);
		String message = args[2];
		
		Socket conn = new Socket(host, port);
		
		chat(conn, message);
	}

	private static void chat(Socket conn, String message) throws IOException {
		BufferedReader reader = null;
		PrintWriter writer = null;
		
		try {
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), UTF8));
			writer = new PrintWriter(new OutputStreamWriter(conn.getOutputStream(), UTF8));
			
			writer.println(message);
			writer.flush();
			
			String response = reader.readLine();
			if (response != null) {
				System.out.println("Server response: " + message);
			}
		} finally {
			IOUtil.closeQuietly(reader);
			IOUtil.closeQuietly(writer);
		}
	}
}
