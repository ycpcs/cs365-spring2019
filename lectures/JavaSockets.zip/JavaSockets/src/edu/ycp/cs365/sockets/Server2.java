package edu.ycp.cs365.sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.SelectableChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

public class Server2 {
	private static final Charset UTF8 = Charset.forName("UTF-8");
	
	private int port;
	private volatile boolean shutdown;
	private AtomicInteger workerCount;
	
	public Server2(int port) {
		this.port = port;
		this.shutdown = false;
		this.workerCount = new AtomicInteger(0);
	}
	
	public void run() throws IOException {
		System.out.println("Listening for connections on port " + port);
		
		ServerSocketChannel ssock = ServerSocketChannel.open();
		ssock.socket().bind(new InetSocketAddress(port));
		ssock.configureBlocking(false); // set to nonblocking
		
		// Use a Selector to monitor the server socket
		Selector selector = Selector.open();
		
		SelectionKey key = ssock.register(selector, SelectionKey.OP_ACCEPT);
		
		while (!shutdown || workerCount.get() > 0) {
			int nready = selector.select(1000L); // timed wait for a client to connect
			
			// In this code, we have only one SelectionKey registered.
			// However, a Selector can be used to monitor many channels
			// simultaneously, in which case multiple SelectionKeys might
			// become ready.  So, in general, a loop over selected keys
			// is necessary.
			Iterator<SelectionKey> iter = selector.selectedKeys().iterator();
			while (iter.hasNext()) {
				SelectionKey skey = iter.next();
				if (skey.isAcceptable()) {
					// Find out which channel is ready.  In this case,
					// it is guaranteed to be the ServerSocketChannel,
					// but in other cases we could be monitoring multiple
					// channels.
					SelectableChannel chan = skey.channel();
					
					// Ready to accept a connection from a client
					SocketChannel schan = ((ServerSocketChannel)chan).accept();
					Worker w = new Worker(schan.socket()); 
					Thread t = new Thread(w);
					t.setDaemon(true); // no thread will join the worker
					workerCount.incrementAndGet(); // a worker is about to start
					t.start();
				}
				// It is crucial to remove the selection key from the selected key set.
				// Otherwise, the key remains in the "acceptable" state, making it
				// seem like the server socket is still ready to accept a connection.
				iter.remove();
			}
		}
	}

	private class Worker implements Runnable {
		private Socket client;
		
		public Worker(Socket client) {
			this.client = client;
		}
		
		@Override
		public void run() {
			try {
				chat(client);
			} catch (IOException e) {
				System.err.println("Exception communicating with client: " + e.getMessage());
			}
			
			// Worker is exiting, decrement worker count
			workerCount.decrementAndGet();
		}
		
		private void chat(Socket client) throws IOException {
			
			BufferedReader reader = null;
			PrintWriter writer = null;
			
			try {
				reader = new BufferedReader(new InputStreamReader(client.getInputStream(), UTF8));
				writer = new PrintWriter(new OutputStreamWriter(client.getOutputStream(), UTF8));
				
				// Continue to chat with the client until a "quit" or "shutdown"
				// command is received.
				boolean done = false;
				while (!done) {
					String message = reader.readLine();
					if (message != null) {
						message = message.trim();
						System.out.println("Received: " + message);
						
						if (message.equals("quit")) {
							done = true;
						} else if (message.equals("shutdown")) {
							done = true;
							shutdown = true;
						} else {
							writer.println(message);
							writer.flush();
						}
					}
				}
			} finally {
				IOUtil.closeQuietly(reader);
				IOUtil.closeQuietly(writer);
			}
		}
	}
	
	public static void main(String[] args) throws IOException {
		if (args.length < 1) {
			System.out.println("Usage: " + Server2.class.getName() + " <port>");
			System.exit(1);
		}
		int port = Integer.parseInt(args[0]);
	
		Server2 server = new Server2(port);
		server.run();
		System.out.println("Done");
	}
}
