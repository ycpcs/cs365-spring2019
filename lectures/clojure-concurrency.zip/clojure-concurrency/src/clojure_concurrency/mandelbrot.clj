(ns clojure-concurrency.mandelbrot)

;; ------------------------------------------------------------
;; Complex numbers
;; ------------------------------------------------------------

; Ensure that complex numbers use doubles to represent the
; real and imaginary components.
(defn make-complex [r i]
  [(double r) (double i)])

(defn complex-add [[a b] [c d]]
  [(+ a c) (+ d b)])

(defn complex-mul [[a b] [c d]]
  [(- (* a c) (* b d)) (+ (* b c) (* a d))])

(defn complex-magnitude [[r i]]
  (Math/sqrt (double (+ (* r r) (* i i)))))

;; ------------------------------------------------------------
;; Mandelbrot set computation
;; ------------------------------------------------------------

; Starting from z = 0+0i, iterate z = z^2 + c until the magnitude
; of z reaches 2 or a maximum iteration count is reached.
(defn mandelbrot-iter [c maxiters]
  (loop [z (make-complex 0 0)
         count 0]
    (if (or (> (complex-magnitude z) 2) (>= count maxiters))
      count
      (recur (complex-add (complex-mul z z) c) (+ count 1)))))

; Compute a single row of iteration counts, starting from
; given real/imaginary values, incrementing real values by r-incr,
; generating n iteration counts, using maxiters as the maximum number
; of iterations.
(defn mandelbrot-compute-row [r i r-incr n maxiters]
  (mapv (fn [index]
          (mandelbrot-iter (make-complex (+ r (* r-incr index)) i) maxiters))
        (range 0 n)))

; Sequential computation, returns a sequence of rows, where
; each row is a sequence of iteration counts as computed
; by mandelbrot-compute-row.  Computes every n'th row starting
; from startrow.
(defn mandelbrot-compute-grid-seq [rmin imin rmax imax ncols nrows maxiters startrow n]
  (let [r-incr (/ (- rmax rmin) ncols)
        i-incr (/ (- imax imin) nrows)]
    (mapv (fn [row]
            (mandelbrot-compute-row rmin (+ imin (* row i-incr)) r-incr ncols maxiters))
          (range startrow nrows n))))

; Sequential computation, computing every row from 0 to nrows-1.
(defn mandelbrot-compute-grid-seq-all [rmin imin rmax imax ncols nrows maxiters]
  (mandelbrot-compute-grid-seq rmin imin rmax imax ncols nrows maxiters 0 1))

; Parallel computation using one future per row.
(defn mandelbrot-compute-grid-par-futures [rmin imin rmax imax ncols nrows maxiters]
  (let [r-incr (/ (- rmax rmin) ncols)
        i-incr (/ (- imax imin) nrows)
        row-fn (fn [row]
                 (future (mandelbrot-compute-row rmin (+ imin (* row i-incr))
                                                 r-incr ncols maxiters)))
        future-results (mapv row-fn (range 0 nrows))]
    (mapv deref future-results)))

; Parallel computation using a fixed number of futures.
; The computation performed by each future handles every n'th
; row (by making a call to mandelbrot-compute-grid-seq).
; This is a relatively efficient way to split up the
; computation over a fixed number of threads.
(defn mandelbrot-compute-grid-par-futures-interleaved [rmin imin rmax imax ncols nrows maxiters nthreads]
  (let [every-nth-row-fn (fn [j]
                           (future (mandelbrot-compute-grid-seq rmin imin rmax imax ncols nrows maxiters j nthreads)))
        partial-results (mapv every-nth-row-fn (range 0 nthreads))]
    (apply interleave (mapv deref partial-results))))
