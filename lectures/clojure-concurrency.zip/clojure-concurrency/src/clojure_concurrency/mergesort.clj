(ns clojure-concurrency.mergesort)

(defn append-all [vec coll]
  (loop [acc vec
         remaining coll]
    (if (empty? remaining)
      acc
      (recur (conj acc (first remaining)) (rest remaining)))))

(defn merge-lists [lv rv]
 (loop [left lv
        right rv
        acc []]
   (cond
     (empty? left) (append-all acc right)
     (empty? right) (append-all acc left)
     :else (let [fl (first left)
                 fr (first right)]
             (if (< fl fr)
               (recur (rest left) right (conj acc fl))
               (recur left (rest right) (conj acc fr)))))))

(defn merge-sort [seq]
  (if (< (count seq) 2)
    seq
    (let [[left right] (split-at (/ (count seq) 2) seq)
          left-sorted (merge-sort left)
          right-sorted (merge-sort right)]
      (merge-lists left-sorted right-sorted))))
      