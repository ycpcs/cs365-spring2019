(ns clojure-concurrency.statecolors)

; Adjacency list vector for US states.
(def state-adjacency-list
  ; Source of data:
  ;  http://writeonly.wordpress.com/2009/03/20/adjacency-list-of-states-of-the-united-states-us/
  ; Note: I modified the data so that the Four Corners states aren't
  ; considered adjacent to their diagnoal neighbors.  The reason is
  ; that adjacency to the diagonal neighbors would make the graph
  ; non-planar, meaning that the feasibility of 4-coloring is not
  ; guaranteed.
  [[:AK]
   [:AL :MS :TN :GA :FL]
   [:AR :MO :TN :MS :LA :TX :OK]
   [:AZ :CA :NV :UT :NM] ; CO
   [:CA :OR :NV :AZ]
   [:CO :WY :NE :KS :OK :NM :UT] ; :AZ
   [:CT :NY :MA :RI]
   [:DC :MD :VA]
   [:DE :MD :PA :NJ]
   [:FL :AL :GA]
   [:GA :FL :AL :TN :NC :SC]
   [:HI]
   [:IA :MN :WI :IL :MO :NE :SD]
   [:ID :MT :WY :UT :NV :OR :WA]
   [:IL :IN :KY :MO :IA :WI]
   [:IN :MI :OH :KY :IL]
   [:KS :NE :MO :OK :CO]
   [:KY :IN :OH :WV :VA :TN :MO :IL]
   [:LA :TX :AR :MS]
   [:MA :RI :CT :NY :NH :VT]
   [:MD :VA :WV :PA :DC :DE]
   [:ME :NH]
   [:MI :WI :IN :OH]
   [:MN :WI :IA :SD :ND]
   [:MO :IA :IL :KY :TN :AR :OK :KS :NE]
   [:MS :LA :AR :TN :AL]
   [:MT :ND :SD :WY :ID]
   [:NC :VA :TN :GA :SC]
   [:ND :MN :SD :MT]
   [:NE :SD :IA :MO :KS :CO :WY]
   [:NH :VT :ME :MA]
   [:NJ :DE :PA :NY]
   [:NM :AZ :CO :OK :TX] ; :UT
   [:NV :ID :UT :AZ :CA :OR]
   [:NY :NJ :PA :VT :MA :CT]
   [:OH :PA :WV :KY :IN :MI]
   [:OK :KS :MO :AR :TX :NM :CO]
   [:OR :CA :NV :ID :WA]
   [:PA :NY :NJ :DE :MD :WV :OH]
   [:RI :CT :MA]
   [:SC :GA :NC]
   [:SD :ND :MN :IA :NE :WY :MT]
   [:TN :KY :VA :NC :GA :AL :MS :AR :MO]
   [:TX :NM :OK :AR :LA]
   [:UT :ID :WY :CO :AZ :NV] ; :NM
   [:VA :NC :TN :KY :WV :MD :DC]
   [:VT :NY :NH :MA]
   [:WA :ID :OR]
   [:WI :MI :MN :IA :IL]
   [:WV :OH :PA :MD :VA :KY]
   [:WY :MT :SD :NE :CO :UT :ID]])

; Build a map of state names to their indices in the adjancency list vector
(def state-to-index-map
  (zipmap (map (fn [lst] (first lst)) state-adjacency-list) (range 0 (count state-adjacency-list))))

; Get index (into adjacency list) of state 
(defn state-index [state]
  (get state-to-index-map state))

; Find neighbors of given state
(defn neighbors-of [state] (rest (get state-adjacency-list (state-index state))))

; Colors to use
(def colors #{:red :green :blue :yellow :purple})

; Refs to store state colors.  Initially, every state is colored red.
(def state-colors
  (vec (repeatedly (count state-adjacency-list) (fn [] (ref :red)))))

; Reset all state colors to red.
(defn reset-state-colors []
  (dosync (doseq [r state-colors] (ref-set r :red))))

; Get a set containing a state's neighbors' current colors
(defn get-neighbor-colors [state]
  (set (mapv (fn [neighbor] (deref (get state-colors (state-index neighbor)))) (neighbors-of state))))

; Attempt to update the color assigned to given state
; in order to make it different than its neighbors.
; Returns true if a good color was found, false otherwise.
(defn update-state-color [state]
  (let [my-color (deref (get state-colors (state-index state)))
        neighbor-colors (get-neighbor-colors state)]
    (if (not (contains? neighbor-colors my-color))
      ; Current color is ok
      true
      ; See what colors are available (not used by neighbors)
      (let [candidates (clojure.set/difference colors neighbor-colors)]
        (if (empty? candidates)
          ; Neighbors have already used all available colors,
          ; so there's no point in choosing a new color
          false
          (do
            ; Set new state color randomly from available candidate colors
            (ref-set (get state-colors (state-index state)) (rand-nth (seq candidates)))
            ; As far as we know, the state's color is now good
            true))))))
            

; Worker function: for some number of iterations, attempt to
; update state color of given state to be different than its
; neighbors.
(defn worker [state num-iters]
  ;(println "Finding color for state " state " using " num-iters " iterations")
  (loop [count 0
         color-is-ok false]
    (if (>= count num-iters)
      (do
        ;(println "Finished for " state)
        color-is-ok)
      (let [found-legal (dosync (update-state-color state))]
        (recur (+ count 1) found-legal)))))

; Create parallel tasks for each state, use them to find a possible
; color for each state.  Each worker will use maxiters as its number
; of iterations.
(defn find-state-colors [maxiters]
  (apply pcalls (map (fn [state] (fn [] (worker state maxiters))) (keys state-to-index-map))))

; Check whether a given state has neighbors which are all
; of different colors.
(defn check-state [state]
  (let [my-color (deref (get state-colors (state-index state)))
        neighbor-colors (get-neighbor-colors state)]
    (let [ok (not (contains? neighbor-colors my-color))]
      (if (not ok)
        (println "Failed to find color for " state))
      ok)))

; Check whether given solution (list of state color assignments) is valid.
(defn check-state-colors []
  (every? identity (mapv check-state (keys state-to-index-map))))
