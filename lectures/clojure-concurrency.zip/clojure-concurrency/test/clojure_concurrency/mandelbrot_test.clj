(ns clojure-concurrency.mandelbrot-test
  (:require [clojure.test :refer :all]
            [clojure-concurrency.mandelbrot :refer :all]))

;(deftest a-test
;  (testing "FIXME, I fail."
;    (is (= 0 1))))
