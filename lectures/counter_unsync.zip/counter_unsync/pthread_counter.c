#include <pthread.h>

#include <stdio.h>
#include <stdlib.h>

typedef struct {
	int count;
} Counter;

void counter_init(Counter *c);
int counter_get(Counter *c);
void counter_incr(Counter *c);

void *worker(void *arg)
{
	Counter *c = arg;

	int i;
	for (i = 0; i < 1000000; i++) {
		counter_incr(c);
	}

	return NULL;
}

int main(void)
{
	pthread_t thread1, thread2;

	Counter *c = malloc(sizeof(Counter));
	counter_init(c);

	pthread_create(&thread1, NULL, &worker, c);
	pthread_create(&thread2, NULL, &worker, c);

	// wait for the threads to complete
	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);

	printf("final count is %d\n", c->count);

	return 0;
}

void counter_init(Counter *c)
{
	c->count = 0;
}

int counter_get(Counter *c)
{
	int val = c->count;
	return val;
}

void counter_incr(Counter *c)
{
	int val = c->count;
	val = val + 1;
	c->count = val;
}
