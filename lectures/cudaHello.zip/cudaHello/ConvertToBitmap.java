import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class ConvertToBitmap {
	private static final int DIM = 800;

	public static void main(String[] args) throws Exception {
		if (args.length != 1) {
			System.err.println("Usage: ConvertToBitmap <input file>");
			System.exit(1);
		}

		String inputFile = args[0];
		BufferedReader reader = new BufferedReader(
			new FileReader(inputFile));

		BufferedImage img = new BufferedImage(DIM, DIM, BufferedImage.TYPE_INT_ARGB);
		Graphics g = img.getGraphics();

		for (int j = 0; j < DIM; j++) {
			String line = reader.readLine();
			Scanner s = new Scanner(line);
			for (int i = 0; i < DIM; i++) {
				int val = s.nextInt();
				Color c;

				if (val == 1000) {
					c = Color.BLACK;
				} else {
					double iterLog = val == 0 ? 0.0 : Math.log10(val) / 3.0;
					int blue = (int) ((1.0 - iterLog)*255);
					int green = (int) (iterLog*255);
					c = new Color(0, green, blue);
				}

				g.setColor(c);
				g.fillRect(i, j, 1, 1);
			}
		}

		reader.close();

		OutputStream os = new BufferedOutputStream(new FileOutputStream("mandel.png"));
		try {
			ImageIO.write(img, "PNG", os);
		} finally {
			os.close();
		}


	}
}
