#include <pthread.h>
#include <unistd.h>

#include <stdio.h>
#include <stdlib.h>

#include "queue.h"

typedef struct {
	queue_t q;
	int max;   // max number of items
	int count; // current number of items

	pthread_mutex_t lock;
	pthread_cond_t cond;
} BoundedQueue;

void boundedqueue_init(BoundedQueue* bq, int max);
void boundedqueue_enqueue(BoundedQueue* bq, void *item);
void* boundedqueue_dequeue(BoundedQueue* bq);

// producer is fast
void *producer(void *arg)
{
	BoundedQueue *bq = arg;
	for (int i = 0; i < 26; i++) {
		char val = 'A' + i;
		char *item = malloc(sizeof(char));
		*item = val;
		boundedqueue_enqueue(bq, item);
		printf("sent %c\n", val);
	}
	return NULL;
}

// consumer is slow
void *consumer(void *arg)
{
	BoundedQueue *bq = arg;
	int done = 0;
	while (!done) {
		char *item = boundedqueue_dequeue(bq);
		printf("received %c\n", *item);
		if (*item == 'Z') {
			done = 1;
		}
		free(item);
		sleep(1);
	}
	return NULL;
}

int main(void)
{
	BoundedQueue *bq = malloc(sizeof(BoundedQueue));
	boundedqueue_init(bq, 5);

	pthread_t thread1, thread2;

	pthread_create(&thread1, NULL, &producer, bq);
	pthread_create(&thread2, NULL, &consumer, bq);

	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);

	printf("done\n");

	return 0;
}

void boundedqueue_init(BoundedQueue* bq, int max)
{
	queue_init(&bq->q);
	bq->max = max;
	bq->count = 0;
	pthread_mutex_init(&bq->lock, NULL);
	pthread_cond_init(&bq->cond, NULL);
}

void boundedqueue_enqueue(BoundedQueue* bq, void *item)
{
	pthread_mutex_lock(&bq->lock);

	while (bq->count >= bq->max) {
		pthread_cond_wait(&bq->cond, &bq->lock);
	}

	queue_enqueue(&bq->q, item);
	bq->count++;
	pthread_cond_broadcast(&bq->cond); // wake up consumer

	pthread_mutex_unlock(&bq->lock);
}

void* boundedqueue_dequeue(BoundedQueue* bq)
{
	pthread_mutex_lock(&bq->lock);

	while (bq->count == 0) {
		pthread_cond_wait(&bq->cond, &bq->lock);
	}

	void *result = queue_dequeue(&bq->q);
	bq->count--;
	pthread_cond_broadcast(&bq->cond); // wake up consumer

	pthread_mutex_unlock(&bq->lock);

	return result;
}

