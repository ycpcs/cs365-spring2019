// CS 365 - Spring 2015 - Exam 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <stdbool.h>
#include <unistd.h>
#include <mpi.h>
#include "grid.h"

// Use this to help divide up the work if you want to
void divide_work(int n, int num_chunks, int chunk_index, int *start_index, int *end_index)
{
	assert(n > 0);
	assert(num_chunks < n);

	int chunk_size = n / num_chunks;
	int r = n % num_chunks;

	*start_index = (chunk_index * chunk_size);

	if (chunk_index < r) {
		*start_index += chunk_index;
	} else {
		*start_index += r;
	}

	*end_index = (*start_index) + chunk_size;
	if (chunk_index < r) {
		(*end_index)++;
	}
}

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	if (argc != 5) {
		fprintf(stderr, "Usage: ./runpar <filename> <q> <N> <M>\n");
		exit(1);
	}

	const char *filename = argv[1];
	int q = atoi(argv[2]);  // the integer q
	int N = atoi(argv[3]);  // number of rows of processes
	int M = atoi(argv[4]);  // number of columns of processes

	printf("filename=%s, N=%i, M=%i\n", filename, N, M);

	// Load the overall (global) Grid
	FILE *fp = fopen(filename, "r");
	if (!fp) {
		fprintf(stderr, "Couldn't open %s: %s\n", filename, strerror(errno));
		exit(1);
	}
	Grid *global = grid_load(fp);
	fclose(fp);

	int global_num_rows = global->rows;
	int global_num_cols = global->cols;

	// TODO: have this process determine its region of the global Grid
	int proc_row = rank / M; // which row of processes is this process in
	int proc_col = rank % M; // which column of processes is this process in

	int eff_w = global_num_cols - 2;
	int eff_h = global_num_rows - 2;

	int chunk_size_horiz = eff_w / M;
	int startx = proc_col * chunk_size_horiz;
	if (proc_col == M - 1) {
		chunk_size_horiz += eff_w % M;
	}
	int endx = startx + chunk_size_horiz;

	int chunk_size_vert = eff_h / N;
	int starty = proc_row * chunk_size_vert;
	if (proc_row == N - 1) {
		chunk_size_vert += eff_h % N;
	}
	int endy = starty + chunk_size_vert;

	printf("Process %i: x %i..%i, y %i..%i\n",
		rank, startx, endx, starty, endy);

	// TODO: local computation: count how many 3x3 blocks in this
	// process's region sum to q
	int local_sum = 0;
	for (int i = starty + 1; i < endy + 1; i++) {
		for (int j = startx + 1; j < endx + 1; j++) {
			int block_sum = 0;
			for (int dy = -1; dy <= 1; dy++) {
				for (int dx = -1; dx <= 1; dx++) {
					block_sum += grid_get_current(global, i + dy, j + dx);
				}
			}
			if (block_sum == q) {
				local_sum++;
			}
		}
	}

	printf("Process %i: local_sum=%i\n", rank, local_sum);

	// TODO: reduce all of the local results to a single
	// overall result, report it (hint: MPI_Reduce)
	int global_sum;
	MPI_Reduce(&local_sum, &global_sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

	if (rank == 0) {
		printf("Result is %i\n", global_sum);
	}

	MPI_Finalize();

	return 0;
}
