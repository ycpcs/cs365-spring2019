// CS 365 - Spring 2017 - Exam 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <stdbool.h>
#include <unistd.h>
#include <mpi.h>
#include "grid.h"

// Use this to help divide up the work if you want to
void divide_work(int n, int num_chunks, int chunk_index, int *start_index, int *end_index)
{
	assert(n > 0);
	assert(num_chunks < n);

	int chunk_size = n / num_chunks;
	int r = n % num_chunks;

	*start_index = (chunk_index * chunk_size);

	if (chunk_index < r) {
		*start_index += chunk_index;
	} else {
		*start_index += r;
	}

	*end_index = (*start_index) + chunk_size;
	if (chunk_index < r) {
		(*end_index)++;
	}
}

// Dynamically allocate an array of zero-initialized int elements.
int *alloc_int_arr(int num_elems)
{
	int *arr = malloc(num_elems * sizeof(int));
	for (int i = 0; i < num_elems; i++) {
		arr[i] = 0;
	}
	return arr;
}

// Find the maximum value in an array of integer values.
int find_max(int *arr, int num_elems)
{
	int max = arr[0];
	for (int i = 1; i < num_elems; i++) {
		if (arr[i] > max) {
			max = arr[i];
		}
	}
	return max;
}

int main(int argc, char **argv)
{
	MPI_Init(&argc, &argv);

	int rank, size;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	if (argc != 4) {
		fprintf(stderr, "Usage: ./runpar <filename> <N> <M>\n");
		exit(1);
	}

	const char *filename = argv[1];
	int N = atoi(argv[2]);  // number of rows of processes
	int M = atoi(argv[3]);  // number of columns of processes

	printf("filename=%s, N=%i, M=%i\n", filename, N, M);

	// Load the overall (global) Grid
	FILE *fp = fopen(filename, "r");
	if (!fp) {
		fprintf(stderr, "Couldn't open %s: %s\n", filename, strerror(errno));
		exit(1);
	}
	Grid *global = grid_load(fp);
	fclose(fp);

	int global_num_rows = global->rows;
	int global_num_cols = global->cols;

	// Allocate arrays for row and column sums.
	// All elements are initialized to zero.
	// Hint: these will be useful to hold the results
	// of the local computation.
	int *col_sums = alloc_int_arr(global_num_cols);
	int *row_sums = alloc_int_arr(global_num_rows);

	// TODO: have this process determine its region of the global Grid
	int proc_row = rank / M; // which row of processes is this process in
	int proc_col = rank % M; // which column of processes is this process in

	// TODO: local computation: compute row and column sums in the
	// local Grid region

	// TODO: find global row and colum sums (hint: use MPI_Reduce,
	// and note that MPI_Reduce can be used with an array of values)

	// TODO: (root process only) find global row and columns
	// with maximum sums
	int *global_col_sums = alloc_int_arr(global_num_cols);
	int *global_row_sums = alloc_int_arr(global_num_rows);

	MPI_Finalize();

	return 0;
}

// vim:ts=4:
