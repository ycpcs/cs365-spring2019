#! /usr/bin/env ruby

def usage
	STDERR.puts "gengrid.rb <nrows> <ncols>"
	exit 1
end

nrows = ARGV.shift || usage
ncols = ARGV.shift || usage

rng = Random.new

puts "#{nrows} #{ncols}"
nrows.to_i.times do
	ncols.to_i.times do
		v = rng.rand(10)
		print "#{v} "
	end
	puts ""
end

# vim:ts=4:
