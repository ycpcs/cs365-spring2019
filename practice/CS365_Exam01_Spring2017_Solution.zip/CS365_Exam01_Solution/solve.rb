#! /usr/bin/env ruby

require 'scanf'

def usage
	STDERR.puts "Usage: solve.rb <filename>"
	exit 1
end

filename = ARGV.shift || usage

grid = []
nrows = 0
ncols = 0

File.open(filename) do |f|
	nrows = f.scanf("%d")[0]
	ncols = f.scanf("%d")[0]

	puts "#{nrows} rows, #{ncols} cols"

	nrows.times do
		grid.push([])
		ncols.times do
			val = f.scanf("%d")[0]
			grid[-1].push(val)
		end
	end
end

rowmax = 0
colmax = 0

nrows.times do |i|
	rowsum = grid[i].inject(0) { |sum, x| sum + x }
	rowmax = rowsum if rowsum > rowmax
end

ncols.times do |j|
	colsum = 0
	nrows.times do |i|
		colsum += grid[i][j]
	end
	colmax = colsum if colsum > colmax
end

puts "Maximum row sum is #{rowmax}"
puts "Maximum column sum is #{colmax}"

# vim:ts=4:
