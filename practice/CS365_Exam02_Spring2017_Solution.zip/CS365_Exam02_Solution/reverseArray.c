// Reverse an array: parallel version

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#define NUM_ELEMENTS 10000000

void swap(int *l, int *r)
{
	int tmp = *l;
	*l = *r;
	*r = tmp;
}

typedef struct {
	int *arr;
	int start, end;
} Work;

void *worker(void *arg) {
	Work *w = arg;

	int *arr = w->arr;
	for (int i = w->start; i < w->end; i++) {
		int j = (NUM_ELEMENTS - i) - 1;
		swap(&arr[i], &arr[j]);
	}

	return NULL;
}

int main(int argc, char **argv)
{
	int *arr, *copy;
	int i, j;
	int num_threads = 2; // default number of threads

	// See if number of threads was specified
	if (argc == 2) {
		num_threads = atoi(argv[1]);
	}

	// TODO: add other variables as needed

	arr = (int *) malloc(NUM_ELEMENTS * sizeof(int));
	copy = (int *) malloc(NUM_ELEMENTS * sizeof(int));

	for (i = 0; i < NUM_ELEMENTS; i++) {
		arr[i] = rand() % 20000000;
		copy[i] = arr[i];
	}

	// TODO: parallelize this loop using multiple threads

	int n = NUM_ELEMENTS/2;
	int chunk_size = n/num_threads;

	Work work[100];
	pthread_t threads[100];
	for (int i = 0; i < num_threads; i++) {
		work[i].arr = arr;
		work[i].start = i*chunk_size;
		work[i].end = (i+1)*chunk_size;
		if (i == num_threads - 1) {
			work[i].end += (n % num_threads);
		}
		pthread_create(&threads[i], NULL, worker, &work[i]);
	}

	for (int i = 0; i < num_threads; i++) {
		pthread_join(threads[i], NULL);
	}

	// Check that swapped array is correct
	for (i = 0, j = NUM_ELEMENTS - 1; i < NUM_ELEMENTS; i++, j--) {
		if (arr[i] != copy[j]) {
			fprintf(stderr, "incorrect reversal\n");
			exit(1);
		}
	}
	printf("success!\n");

	return 0;
}

