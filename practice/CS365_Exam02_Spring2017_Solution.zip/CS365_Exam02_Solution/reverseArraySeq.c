// Reverse an array: sequential version

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#define NUM_ELEMENTS 10000000

void swap(int *l, int *r)
{
	int tmp = *l;
	*l = *r;
	*r = tmp;
}

int main(int argc, char **argv)
{
	int *arr, *copy;
	int i, j;

	// TODO: add other variables as needed

	arr = (int *) malloc(NUM_ELEMENTS * sizeof(int));
	copy = (int *) malloc(NUM_ELEMENTS * sizeof(int));

	for (i = 0; i < NUM_ELEMENTS; i++) {
		arr[i] = rand() % 20000000;
		copy[i] = arr[i];
	}

	// TODO: parallelize this loop using multiple threads
	for (i = 0; i < NUM_ELEMENTS / 2; i++) {
		j = (NUM_ELEMENTS - i) - 1;
		swap(&arr[i], &arr[j]);
	}

	// Check that swapped array is correct
	for (i = 0, j = NUM_ELEMENTS - 1; i < NUM_ELEMENTS; i++, j--) {
		if (arr[i] != copy[j]) {
			fprintf(stderr, "incorrect reversal\n");
			exit(1);
		}
	}
	printf("success!\n");

	return 0;
}

